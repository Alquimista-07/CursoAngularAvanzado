import { MedicosComponent } from './medicos.component';
import { MedicosService } from './medicos.service';


describe('MedicosComponent', () => {

    let componente: MedicosComponent;

    beforeEach( () => {
        
    });


    it('', () => {

   
    });


});
